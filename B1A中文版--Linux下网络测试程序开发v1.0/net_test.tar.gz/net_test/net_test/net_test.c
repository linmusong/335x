#include <ctype.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <linux/fb.h>
#include <unistd.h>
#include <termios.h>
#include <string.h>
#include <linux/kd.h>
#include <sys/ioctl.h>
#include<sys/stat.h>

#define CMD_IFCONFIG    "ifconfig eth0 192.168.199.222 1>/tmp/net  2>/tmp/net"
#define CMD_PING  "ping -c 2 192.168.199.154 1>/tmp/net  2>/tmp/net"
#define CMD_GREP  "cat /tmp/net | grep '2 packets transmitted, 2 packets received, 0% packet loss' 1>/tmp/net_info 2>/tmp/net_info"
#define ERRO_INFO  "/tmp/net_info"
#define CMD_NET_DOWN	"ifconfig eth0 down"
#define CMD_NET_UP    	"ifconfig eth0 up"

int main(void)
{
	struct stat stat_buf;

	system(CMD_IFCONFIG);
		printf("CMD_IFCONFIG OK!\n\r");
	system(CMD_PING);
		printf("CMD_PING OK!\n\r");
	system(CMD_GREP);
		printf("CMD_GREP OK!\n\r");

  	if (stat(ERRO_INFO,&stat_buf)<0) 
  	{   
  		printf("Failed:buf<0\n\r");
		return -1;   
		
 	}  
	if (stat_buf.st_size <= 0) 
	{
		printf("Failed:size<=0\n\r");
		return -1;	
	}		
	printf("net is ok!\n\r");
	return 0;
}	

