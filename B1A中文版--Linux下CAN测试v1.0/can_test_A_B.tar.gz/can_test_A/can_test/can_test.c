#include <ctype.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <linux/fb.h>
#include <unistd.h>
#include <termios.h>
#include <string.h>
#include <linux/kd.h>
#include <sys/ioctl.h>
#include <sys/stat.h>

#include "fbutils.h"

#define CAN_INIT		"canconfig can0 bitrate 125000 ctrlmode triple-sampling on"
#define CAN_EN			"canconfig can0 start"
#define CAN_RECIVE		"candump can0 1>/tmp/can"
#define CAN_SEND                "cansend can0 -i 0x10 0x11 0x22 0x33 0x44 0x55 0x66 0x77 0x88"
#define CAN_STOP		"canconfig can0 stop 2>>/tmp/can"
#define CMD_GREP		"cat /tmp/can | grep \"11 22 33 44 55 66 77 88\" 1>/tmp/can_info" 

#define ERRO_INFO		"/tmp/can_info"

void *thread_function(void *arg)
{
    int num_read;
		
	printf("time start!\n\r");
	sleep(1);
	printf("1s\n\r");
	sleep(1);
	printf("2s\n\r");
	sleep(1);
	printf("3s\n\r");
	sleep(1);
	printf("4s\n\r");
	sleep(1);
	printf("5s\n\r");
	
	system(CAN_STOP);
	pthread_exit("can stop!");

}
int main(void)
{
	char buff[256];
	struct stat stat_buf;
	pid_t pid;
	pthread_t a_thread;
	int res = 0;
   
	system (CAN_INIT);
	system (CAN_EN);
	usleep (200000);

	system (CAN_SEND);
	usleep(50000);
	
	res = pthread_create(&a_thread, NULL, thread_function, NULL);

	if (res != 0){
		perror("Thread creation failed");
		exit(1);
	}
	system (CAN_RECIVE);

	system (CMD_GREP);
	if (stat (ERRO_INFO, &stat_buf) < 0)
		return -1;
	if (stat_buf.st_size <= 0)
		return -1;

	printf("this is success\n");

	return 0;
}

